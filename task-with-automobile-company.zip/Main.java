import java.util.*;
public class Main{
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        int vehicle=sc.nextInt();
        int wheels=sc.nextInt();
        int result=((4*vehicle)-wheels)/2;
        if(wheels>2 && (wheels%2==0) && vehicle<wheels){
            System.out.println("Two wheelers = "+result);
            System.out.print("Four wheelers = "+(vehicle-result));
        }
    }
}